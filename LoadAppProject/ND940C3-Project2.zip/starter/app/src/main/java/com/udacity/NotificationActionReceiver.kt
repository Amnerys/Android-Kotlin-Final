package com.udacity

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK

class NotificationActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.extras != null) {
            val downloadId = intent.extras!!.getLong(MainActivity.DOWNLOAD_ID)
            val fileName = intent.extras!!.getString(MainActivity.SELECTED_FILE)

            if (intent.action.equals("See changes", ignoreCase = true)) {
                val intentt = Intent(context, DetailActivity::class.java)
                intentt.putExtra(MainActivity.DOWNLOAD_ID, downloadId)
                intentt.putExtra(MainActivity.SELECTED_FILE, fileName)
                intentt.addFlags(FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intentt)
                val notificationManager =
                    context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(0)
            }
        }
    }
}