package com.udacity

import android.animation.*
import android.content.Context
import android.graphics.*
import android.os.Build
import android.text.TextPaint
import android.util.AttributeSet
import android.view.View
import kotlin.properties.Delegates


class LoadingButton @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {
    private var horizontalProgressAnimator: ValueAnimator? = null
    private var circlularAnim: ValueAnimator? = null
    private var circularProgress = 0f
    private var canvas: Canvas? = null
    private var widthSize = 0
    private var horizontalProgressWidth = 0
    private var heightSize = 0
    private var mBackgroundColor = 0
    private var mTextColor = 0
    private var mText: CharSequence = ""
    val circularProgressPaint = Paint()
    private val topX = 0
    private var textSize = 0
    val topY = 0f
    var mProgressColor: Int = 0
    private val mCornerRadius = 10
    val mBackgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    val DEFAULT_PROGCOLOR: Int = Color.parseColor("#004349")
    val mTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG);
    private var animValue = 0
    private var buttonState: ButtonState by Delegates.observable<ButtonState>(ButtonState.Completed) { p, old, new ->

    }


    init {
        buttonState == ButtonState.Completed
        val a = getContext().theme
            .obtainStyledAttributes(attrs, R.styleable.LoadingButton, 0, 0)
        try {
            textSize = a.getDimensionPixelSize(
                R.styleable.LoadingButton_textSize,
                15
            )
            mProgressColor = a.getColor(
                R.styleable.LoadingButton_progColor,
                DEFAULT_PROGCOLOR
            )

            mBackgroundColor = a.getColor(R.styleable.LoadingButton_background_color, Color.BLACK);
            mTextColor = a.getColor(R.styleable.LoadingButton_text_color, Color.WHITE)
            mText = a.getText(R.styleable.LoadingButton_text)
        } finally {
            a.recycle();

        }

    }


    fun setValue(animatedValue: Int) {
        animValue = animatedValue
        invalidate()
    }


    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        this.canvas = canvas

        mBackgroundColor = resources.getColor(R.color.colorPrimary);
        mTextColor = resources.getColor(R.color.white)
        if (buttonState == ButtonState.Loading) {
            mText = resources.getText(R.string.button_loading)
        } else if (buttonState == ButtonState.Completed) {
            mText = resources.getText(R.string.button_name)
        }else{
            mText = resources.getText(R.string.download_completed)
        }
        setButton(canvas)

    }

    private fun setButton(canvas: Canvas?) {
        this.canvas = canvas
        val bgRectf = RectF(
            topX.toFloat(), topY,
            canvas!!.width.toFloat(),
            canvas.height.toFloat()
        )
        canvas.drawRoundRect(
            bgRectf,
            mCornerRadius.toFloat(),
            mCornerRadius.toFloat(),
            mBackgroundPaint
        )
        canvas.drawColor(mBackgroundColor)
        val bounds = Rect()
        mTextPaint.color = mTextColor
        mTextPaint.textAlign = Paint.Align.CENTER
        mTextPaint.textSize = textSize.toFloat()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            mTextPaint.getTextBounds(mText, topX, mText.toString().length, bounds)
            mTextPaint.getTextBounds(
                mText,
                topX,
                mText.length,
                bounds
            )
        }


        val xPos = (canvas.width - bounds.width()) / 2
        val textAdjust = (mTextPaint.descent() + mTextPaint.ascent()).toInt() / 2
        val yPos = canvas.height / 2 - textAdjust
        canvas.drawText(mText.toString(), xPos.toFloat(), yPos.toFloat(), mTextPaint)

        val bgRectff = RectF(
            topX.toFloat(), topY,
            horizontalProgressWidth.toFloat(),
            canvas.height.toFloat()
        )
        mBackgroundPaint.color = mProgressColor
        canvas.drawRoundRect(
            bgRectff,
            mCornerRadius.toFloat(),
            mCornerRadius.toFloat(),
            mBackgroundPaint
        )

        circularProgressPaint.color = resources.getColor(R.color.colorAccent)
        val bgRectfff = RectF(
            (widthSize / 2).toFloat() - 15f, 10f,
            (widthSize / 2).toFloat() + 35f,
            (heightSize / 2).toFloat()
        )
        canvas.drawArc(bgRectfff, 0f, circularProgress, true, circularProgressPaint);
        if (buttonState == ButtonState.Clicked) {
            setLoadingState(ButtonState.Loading)
            increaseWidth()
        }

    }

    fun increaseWidth() {
        buttonState = ButtonState.Completed
        horizontalProgressAnimator = ValueAnimator.ofInt(widthSize - widthSize, widthSize)
        horizontalProgressAnimator!!.addUpdateListener { valueAnimator ->
            val value = valueAnimator.animatedValue as Int
            if(value==widthSize){
                if(buttonState==ButtonState.Completed){
                    horizontalProgressAnimator!!.cancel()
                    circlularAnim!!.cancel()
                    setLoadingState(ButtonState.Completed)
                }else{
                    this@LoadingButton.mProgressColor = resources.getColor(R.color.colorPrimaryDark)
                    this.horizontalProgressWidth = value
                    this@LoadingButton.invalidate()
                    this@LoadingButton.requestLayout()
                }
            }else{
                this@LoadingButton.mProgressColor = resources.getColor(R.color.colorPrimaryDark)
                this.horizontalProgressWidth = value
                this@LoadingButton.invalidate()
                this@LoadingButton.requestLayout()
            }

        }
        circlularAnim = ValueAnimator.ofFloat(0f, 360f)
        circlularAnim!!.addUpdateListener { valueAnimator ->
            val value = valueAnimator.animatedValue as Float

            this@LoadingButton.circularProgress = value
            this@LoadingButton.invalidate()
            this@LoadingButton.requestLayout()
        }

        horizontalProgressAnimator!!.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator?) {
                super.onAnimationEnd(animation)
                if (buttonState == ButtonState.Loading) {
                    this@LoadingButton.mProgressColor = resources.getColor(R.color.colorPrimaryDark)
                    this@LoadingButton.horizontalProgressWidth = 0
                    buttonState = ButtonState.Clicked
                    this@LoadingButton.invalidate()
                    this@LoadingButton.requestLayout()
                }
            }
        })
        horizontalProgressAnimator!!.duration = 1800
        circlularAnim!!.duration = 1500
        horizontalProgressAnimator!!.repeatCount = 1
        circlularAnim!!.repeatCount = 1
        horizontalProgressAnimator!!.start()
        circlularAnim!!.start()


    }


    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val minw: Int = paddingLeft + paddingRight + suggestedMinimumWidth
        val w: Int = resolveSizeAndState(minw, widthMeasureSpec, 1)
        val h: Int = resolveSizeAndState(
            MeasureSpec.getSize(w),
            heightMeasureSpec,
            0
        )
        widthSize = w
        heightSize = h
        setMeasuredDimension(w, h)
    }


    fun setLoadingState(state: ButtonState) {
        buttonState = state
        if (buttonState == ButtonState.Completed) {
            if (circlularAnim != null) {
                circlularAnim!!.cancel()
                circularProgress = 0f
            }
            if (horizontalProgressAnimator != null) {
                horizontalProgressAnimator!!.cancel()
                horizontalProgressWidth = 0
            }
        }
        invalidate()
        requestLayout()
    }


}