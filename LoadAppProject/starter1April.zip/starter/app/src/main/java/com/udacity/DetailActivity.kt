package com.udacity

import android.app.DownloadManager
import android.content.Intent
import android.database.Cursor
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_detail.*


class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        setSupportActionBar(toolbar)
       // val download = intent.extras!!.getLong(MainActivity.DOWNLOAD_ID)
        val fileName = intent.extras!!.getString(MainActivity.SELECTED_FILE)
        downloadStatus.text = resources.getString(R.string.download_completed)
        downloadPath.text = fileName
        motion_layout.transitionToStart()
        custom_button.setOnClickListener {
            motion_layout.transitionToEnd()
               val intentt = Intent(this@DetailActivity, MainActivity::class.java)
               intentt.flags=Intent.FLAG_ACTIVITY_NEW_TASK
               intentt.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
               intentt.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
               startActivity(intentt)
               finish()
        }
    }

}
